from flask import Flask, request, jsonify
from sentence_transformers import SentenceTransformer, util
import os

app = Flask(__name__)
model = SentenceTransformer('paraphrase-MiniLM-L3-v2')


@app.route('/')
def home():
    return "API Running 🚀"


# 🔥 Static issues
STATIC_ISSUES = [
    {
        "id": 1,
        "issue": "Internet connection is very slow"
    },
    {
        "id": 2,
        "issue": "Unable to login to the application"
    },
    {
        "id": 3,
        "issue": "Server is not responding"
    },
    {
        "id": 4,
        "issue": "Payment gateway failed during checkout"
    },
    {
        "id": 5,
        "issue": "Email notifications are not received"
    }
]

# 🔥 Precompute embeddings once
STATIC_EMBEDDINGS = [
    model.encode(item["issue"])
    for item in STATIC_ISSUES
]


@app.route('/check', methods=['POST'])
def check():
    data = request.json

    if not data or 'issue' not in data:
        return jsonify({"error": "Invalid input"}), 400

    new_issue = data['issue']

    existing_issues = [item["issue"] for item in STATIC_ISSUES]
    existing_ids = [item["id"] for item in STATIC_ISSUES]

    # Encode new issue
    new_vec = model.encode(new_issue)

    # Cosine similarity
    scores = util.cos_sim(new_vec, STATIC_EMBEDDINGS)[0]

    best_index = int(scores.argmax())
    best_score = float(scores[best_index])

    # Build results
    results = [
        {
            "issue": existing_issues[i],
            "score": float(scores[i]),
            "issue_id": existing_ids[i]
        }
        for i in range(len(existing_issues))
    ]

    # Sort highest score first
    results = sorted(results, key=lambda x: x["score"], reverse=True)

    # Top 5
    top_5 = results[:5]

    return jsonify({
        "results": top_5,
        "best_match_id": existing_ids[best_index],
        "best_score": best_score,
        "best_match": existing_issues[best_index]
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 6001))
    app.run(host="0.0.0.0", port=port)