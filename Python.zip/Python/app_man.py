from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer('local_model')

# Static issues
STATIC_ISSUES = [
    {
        "id": 1,
        "issue": "Internet connection is very slow"
    },
    {
        "id": 2,
        "issue": "Unable to login to the application"
    },
    {
        "id": 3,
        "issue": "Server is not responding"
    },
    {
        "id": 4,
        "issue": "Payment gateway failed during checkout"
    },
    {
        "id": 5,
        "issue": "Email notifications are not received"
    }
]

# Precompute embeddings
STATIC_EMBEDDINGS = [
    model.encode(item["issue"])
    for item in STATIC_ISSUES
]


def check_issue(new_issue):
    existing_issues = [item["issue"] for item in STATIC_ISSUES]
    existing_ids = [item["id"] for item in STATIC_ISSUES]

    # Encode input
    new_vec = model.encode(new_issue)

    # Similarity
    scores = util.cos_sim(new_vec, STATIC_EMBEDDINGS)[0]

    # Prepare results
    results = [
        {
            "issue": existing_issues[i],
            "score": float(scores[i]),
            "issue_id": existing_ids[i]
        }
        for i in range(len(existing_issues))
    ]

    # Sort
    results = sorted(results, key=lambda x: x["score"], reverse=True)

    return results


# 🔥 TEST
if __name__ == "__main__":

    test_issue = "Cannot sign into my account"

    response = check_issue(test_issue)

    print("\nInput Issue:")
    print(test_issue)

    print("\nTop Matches:")
    for item in response:
        print(item)