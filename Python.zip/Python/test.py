from sentence_transformers import SentenceTransformer

# Download model from Hugging Face
model = SentenceTransformer('paraphrase-MiniLM-L3-v2')

# Save locally
model.save('./local_model')

print("Model saved successfully")