from flask import Flask, request, jsonify
from sentence_transformers import SentenceTransformer, util
import os
import mysql.connector
import json

app = Flask(__name__)
model = SentenceTransformer('paraphrase-MiniLM-L3-v2')


def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="live_demo"
    )


@app.route('/')
def home():
    return "API Running 🚀"


@app.route('/check', methods=['POST'])
def check():
    data = request.json

    if not data or 'issue' not in data:
        return jsonify({"error": "Invalid input"}), 400

    new_issue = data['issue']

    _ids, existing_issues, existing_vecs = fetch_existing_issues()

    if not existing_issues:
        return jsonify({"error": "No existing issues"}), 400

    # encode new issue
    new_vec = model.encode(new_issue)

    # cosine similarity
    scores = util.cos_sim(new_vec, existing_vecs)[0]

    best_index = int(scores.argmax())
    best_score = float(scores[best_index])

    results = []


    # 🔥 combine issue + score
    results = [
        # {"issue": existing_issues[i], "score": float(scores[i]), "vector": existing_vecs[i], "issue_id": _ids[i]}
        {"issue": existing_issues[i], "score": float(scores[i]), "issue_id": _ids[i]}
        for i in range(len(existing_issues))
    ]

    # 🔥 sort by score (highest first)
    results = sorted(results, key=lambda x: x["score"], reverse=True)

    # 🔥 take top 5
    top_5 = results[:5]

    return jsonify({
        "results": top_5,
        "best_match_id" : _ids[best_index],
        "best_score" : best_score,
        "best_match" : existing_issues[best_index]
    })


def fetch_existing_issues():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, issue, embeddings
        FROM cu_problem_solving_sheet
        WHERE (chosen_soln_id IS NOT NULL AND chosen_soln_id != '')
        AND status != '4' LIMIT 5
    """)

    rows = cursor.fetchall()

    _ids = []
    issues = []
    embeddings = []

    for row in rows:
        id_, issue, emb = row

        # if embedding missing → generate
        # if emb == 'Warming server got tss04':
        if emb is None or emb == '':
            emb = model.encode(issue)
            emb = emb.tolist()
            # print(json.dumps(emb.tolist()))
            cursor.execute(
                "UPDATE cu_problem_solving_sheet SET embeddings=%s WHERE id=%s",
                (json.dumps(emb), id_)
            )
            conn.commit()

        else:
            # convert stored embedding back to vector using same model format
            emb = json.loads(emb)

        _ids.append(id_)
        issues.append(issue)
        embeddings.append(emb)

    cursor.close()
    conn.close()
    
    return _ids, issues, embeddings


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5001))
    app.run(host="0.0.0.0", port=port)