<?php
header("Content-Type: application/json");

$url = "http://127.0.0.1:6001/check";

$data = [
    "issue" => "Cannot login to my account"
];

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json"
]);

curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo "Curl Error: " . curl_error($ch);
} else {
    // echo "Response:\n";
    echo $response;
}

curl_close($ch);

?>