import { motion } from "framer-motion";
import { Sparkles, UserCheck, IndianRupee, AlarmClock, Navigation, Headphones } from "lucide-react";
import { SectionHead } from "./Services";

const features = [
  { icon: Sparkles, title: "Sanitized Cars", desc: "Every cab cleaned & sanitized before each trip." },
  { icon: UserCheck, title: "Professional Drivers", desc: "Background-verified and trained chauffeurs." },
  { icon: IndianRupee, title: "Transparent Pricing", desc: "No surge, no hidden charges. What you see is what you pay." },
  { icon: AlarmClock, title: "On-Time Pickup", desc: "98% of our rides reach pickup point on schedule." },
  { icon: Navigation, title: "GPS Tracking", desc: "Real-time location sharing with your loved ones." },
  { icon: Headphones, title: "24×7 Support", desc: "Dedicated support team available round the clock." },
];

export function WhyUs() {
  return (
    <section id="about" className="py-20 md:py-28 bg-muted/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="Why Choose Us" title="The We Taxi difference" subtitle="Built for safety, comfort and trust on every kilometre." />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.06 }}
              className="bg-card rounded-3xl p-7 border border-border shadow-soft flex gap-4"
            >
              <div className="size-12 shrink-0 rounded-2xl bg-primary/15 grid place-items-center">
                <f.icon className="size-5 text-foreground" />
              </div>
              <div>
                <h3 className="font-bold text-lg">{f.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
