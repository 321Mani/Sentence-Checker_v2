import { motion } from "framer-motion";
import { ArrowRight, Clock, MapPin } from "lucide-react";
import { SectionHead } from "./Services";

const routes = [
  { from: "Chennai", to: "Bangalore", km: 350, time: "6h 30m", fare: 4499 },
  { from: "Chennai", to: "Pondicherry", km: 160, time: "3h 15m", fare: 2199 },
  { from: "Chennai", to: "Trichy", km: 330, time: "5h 45m", fare: 4199 },
  { from: "Chennai", to: "Madurai", km: 460, time: "8h 00m", fare: 5499 },
  { from: "Chennai", to: "Coimbatore", km: 500, time: "8h 30m", fare: 5999 },
  { from: "Madurai", to: "Rameswaram", km: 175, time: "3h 30m", fare: 2399 },
];

export function PopularRoutes() {
  return (
    <section id="routes" className="py-20 md:py-28 bg-muted/40 relative overflow-hidden">
      <div className="absolute top-0 right-0 size-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="Popular Routes" title="Trusted intercity routes at unbeatable fares" subtitle="Transparent pricing — no hidden charges, no surge pricing." />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {routes.map((r, i) => (
            <motion.div
              key={`${r.from}-${r.to}`}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.06 }}
              className="glass rounded-3xl p-6 hover:shadow-elevated transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs text-muted-foreground font-semibold uppercase">From → To</div>
                  <div className="mt-1 font-display font-bold text-xl flex items-center gap-2">
                    {r.from}
                    <ArrowRight className="size-4 text-primary" />
                    {r.to}
                  </div>
                </div>
                <div className="size-10 rounded-xl bg-primary/20 grid place-items-center">
                  <MapPin className="size-4 text-foreground" />
                </div>
              </div>
              <div className="mt-5 flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><MapPin className="size-3.5" /> {r.km} km</span>
                <span className="flex items-center gap-1.5"><Clock className="size-3.5" /> {r.time}</span>
              </div>
              <div className="mt-5 flex items-center justify-between pt-5 border-t border-border/60">
                <div>
                  <div className="text-xs text-muted-foreground">Starting at</div>
                  <div className="font-display font-extrabold text-2xl">₹{r.fare.toLocaleString()}</div>
                </div>
                <button className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-ink text-background text-sm font-semibold hover:bg-primary hover:text-brand-foreground transition-colors">
                  Book Now <ArrowRight className="size-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
