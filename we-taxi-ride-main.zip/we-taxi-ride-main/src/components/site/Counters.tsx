import { motion, useInView, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect, useRef } from "react";
import { Star } from "lucide-react";

const stats = [
  { value: 50000, suffix: "+", label: "Happy Customers" },
  { value: 500, suffix: "+", label: "Verified Drivers" },
  { value: 100, suffix: "+", label: "Routes Covered" },
  { value: 24, suffix: "/7", label: "Customer Support" },
];

export function Counters() {
  return (
    <section className="py-12 md:py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-card rounded-2xl p-6 border border-border shadow-soft text-center"
            >
              <div className="font-display font-extrabold text-3xl md:text-4xl text-foreground">
                <Counter to={s.value} />{s.suffix}
              </div>
              <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
            </motion.div>
          ))}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="col-span-2 lg:col-span-1 bg-gradient-brand rounded-2xl p-6 shadow-brand text-brand-foreground"
          >
            <div className="flex items-center gap-1">
              {[1,2,3,4,5].map(i => <Star key={i} className="size-4 fill-current" />)}
            </div>
            <div className="mt-2 font-display font-extrabold text-2xl">4.9 / 5</div>
            <div className="text-xs font-medium opacity-80">Rated on Google</div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Counter({ to }: { to: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const count = useMotionValue(0);
  const rounded = useTransform(count, (v) => Math.floor(v).toLocaleString());
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (inView) {
      const controls = animate(count, to, { duration: 2, ease: "easeOut" });
      return controls.stop;
    }
  }, [inView, to, count]);

  useEffect(() => {
    return rounded.on("change", (v) => {
      if (ref.current) ref.current.textContent = v;
    });
  }, [rounded]);

  return <motion.span ref={ref}>0</motion.span>;
}
