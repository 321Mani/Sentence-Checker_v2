import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { SectionHead } from "./Services";

const faqs = [
  { q: "What is one-way taxi?", a: "One-way taxi means you pay only for the side you travel. No return charges. Ideal for intercity travel where you don't need a return ride." },
  { q: "Is toll included in the fare?", a: "Toll charges, state permits, and parking are additional and paid as per actuals. We are fully transparent about these extras upfront." },
  { q: "Is driver bata included?", a: "For trips under 12 hours, driver bata is included. For overnight trips, a minimal driver allowance of ₹400/night applies." },
  { q: "Do you provide airport pickup?", a: "Yes. We offer 24/7 airport pickup and drop services for Chennai, Coimbatore, Madurai, Trichy and Bangalore airports." },
  { q: "Can I book night travel?", a: "Absolutely. We operate 24×7. For trips between 10 PM and 6 AM, a small night charge of ₹250 applies for driver safety." },
  { q: "Which payment methods are accepted?", a: "We accept UPI, all major credit/debit cards, net banking and cash. Pay after the ride — no advance required for most trips." },
];

export function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <section className="py-20 md:py-28 bg-muted/40">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="FAQ" title="Frequently asked questions" />
        <div className="mt-10 space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q} className="bg-card rounded-2xl border border-border overflow-hidden">
                <button
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  className="w-full flex items-center justify-between gap-4 p-5 text-left"
                >
                  <span className="font-semibold text-foreground">{f.q}</span>
                  <motion.span animate={{ rotate: isOpen ? 45 : 0 }} className="size-8 rounded-full bg-primary/15 grid place-items-center shrink-0">
                    <Plus className="size-4" />
                  </motion.span>
                </button>
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">{f.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
