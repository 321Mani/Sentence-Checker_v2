import { motion } from "framer-motion";
import { MapPin, Calendar, Clock, Car, Search, ShieldCheck, BadgeCheck, Navigation, Sparkles, Star } from "lucide-react";
import heroImg from "@/assets/hero-taxi.jpg";

const badges = [
  { icon: Clock, label: "24/7 Service" },
  { icon: ShieldCheck, label: "Verified Drivers" },
  { icon: BadgeCheck, label: "No Hidden Charges" },
  { icon: Navigation, label: "GPS Enabled" },
];

export function Hero() {
  return (
    <section id="home" className="relative pt-28 md:pt-32 pb-16 md:pb-24 bg-gradient-hero overflow-hidden">
      <div className="absolute top-20 -left-20 size-72 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 size-96 bg-primary/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-card border border-border text-xs font-semibold text-foreground/70 shadow-soft">
            <Sparkles className="size-3.5 text-primary" /> Tamil Nadu's #1 Intercity Taxi
          </span>
          <h1 className="mt-5 font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl leading-[1.05] tracking-tight">
            Book Affordable <span className="relative inline-block">
              <span className="relative z-10">One-Way Taxi</span>
              <span className="absolute inset-x-0 bottom-1 h-3 bg-primary/40 -z-0" />
            </span> Across Tamil Nadu
          </h1>
          <p className="mt-5 text-base md:text-lg text-muted-foreground max-w-xl">
            Safe, reliable & affordable taxi services for airport transfers, outstation travel and city-to-city rides.
          </p>

          <div className="mt-6 flex flex-wrap gap-2">
            {badges.map((b) => (
              <div key={b.label} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-card border border-border text-xs font-medium shadow-soft">
                <b.icon className="size-3.5 text-primary" /> {b.label}
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="relative"
        >
          <div className="relative rounded-3xl overflow-hidden shadow-elevated">
            <img src={heroImg} alt="We Taxi premium yellow cab on Tamil Nadu highway" width={1280} height={1280} className="w-full h-[420px] md:h-[520px] object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent" />

            {/* Floating rating card */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="absolute top-5 left-5 glass rounded-2xl p-3 shadow-elevated"
            >
              <div className="flex items-center gap-2">
                <div className="flex -space-x-1">
                  {[1,2,3].map(i => (
                    <div key={i} className="size-7 rounded-full bg-gradient-brand border-2 border-white" />
                  ))}
                </div>
                <div className="text-xs">
                  <div className="font-bold text-foreground">50,000+</div>
                  <div className="text-muted-foreground">Happy riders</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="absolute bottom-5 right-5 glass rounded-2xl p-3 shadow-elevated"
            >
              <div className="flex items-center gap-2">
                <div className="size-9 rounded-xl bg-primary grid place-items-center">
                  <Star className="size-4 text-brand-foreground fill-current" />
                </div>
                <div className="text-xs">
                  <div className="font-bold text-foreground">4.9 / 5.0</div>
                  <div className="text-muted-foreground">Google Reviews</div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Booking form - full width below */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="relative max-w-6xl mx-auto px-4 sm:px-6 mt-10 lg:-mt-12 lg:relative"
      >
        <BookingForm />
      </motion.div>
    </section>
  );
}

function BookingForm() {
  return (
    <form
      onSubmit={(e) => e.preventDefault()}
      className="bg-card rounded-3xl shadow-elevated border border-border p-4 md:p-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
        <Field icon={MapPin} label="Pickup" placeholder="Chennai" />
        <Field icon={MapPin} label="Drop" placeholder="Bangalore" />
        <Field icon={Calendar} label="Date" type="date" />
        <Field icon={Clock} label="Time" type="time" />
        <SelectField icon={Car} label="Cab Type" options={["Sedan", "SUV", "Hatchback", "Innova Crysta"]} />
      </div>
      <div className="mt-4 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex gap-2 text-xs text-muted-foreground">
          <span className="px-2.5 py-1 rounded-full bg-muted">One Way</span>
          <span className="px-2.5 py-1 rounded-full bg-primary/15 text-foreground font-medium">Round Trip</span>
          <span className="px-2.5 py-1 rounded-full bg-muted">Airport</span>
        </div>
        <button className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-ink text-background font-semibold hover:opacity-90 active:scale-[0.98] transition shadow-elevated">
          <Search className="size-4" /> Search Ride
        </button>
      </div>
    </form>
  );
}

function Field({ icon: Icon, label, placeholder, type = "text" }: { icon: typeof MapPin; label: string; placeholder?: string; type?: string }) {
  return (
    <label className="block group">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1 flex items-center gap-2 px-3 py-2.5 rounded-xl border border-border bg-background focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20 transition">
        <Icon className="size-4 text-primary shrink-0" />
        <input type={type} placeholder={placeholder} className="bg-transparent text-sm font-medium w-full outline-none placeholder:text-muted-foreground" />
      </div>
    </label>
  );
}

function SelectField({ icon: Icon, label, options }: { icon: typeof Car; label: string; options: string[] }) {
  return (
    <label className="block">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1 flex items-center gap-2 px-3 py-2.5 rounded-xl border border-border bg-background focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20 transition">
        <Icon className="size-4 text-primary shrink-0" />
        <select className="bg-transparent text-sm font-medium w-full outline-none cursor-pointer">
          {options.map(o => <option key={o}>{o}</option>)}
        </select>
      </div>
    </label>
  );
}
