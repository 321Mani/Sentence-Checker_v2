import { motion } from "framer-motion";
import { ArrowRight, Plane, Repeat, MapPinned, Briefcase, Users, Route } from "lucide-react";

const services = [
  { icon: Route, title: "One Way Taxi", desc: "Pay only one side fare. No return charges across Tamil Nadu." },
  { icon: Repeat, title: "Round Trip Taxi", desc: "Best value packages for round trips with overnight stays." },
  { icon: Plane, title: "Airport Taxi", desc: "On-time pickup & drop for Chennai, Coimbatore & Madurai airports." },
  { icon: MapPinned, title: "Outstation Taxi", desc: "Comfortable long-distance travel across South India." },
  { icon: Briefcase, title: "Corporate Travel", desc: "Dedicated fleet for businesses with monthly billing." },
  { icon: Users, title: "Family Tour Packages", desc: "Curated tourist packages with experienced drivers." },
];

export function Services() {
  return (
    <section id="services" className="py-20 md:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="Our Services" title="Premium taxi services for every journey" subtitle="From quick airport runs to long outstation trips — we've got you covered." />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.07 }}
              whileHover={{ y: -6 }}
              className="group relative bg-card rounded-3xl p-7 border border-border shadow-soft hover:shadow-elevated hover:border-primary/40 transition-all"
            >
              <div className="size-14 rounded-2xl bg-gradient-brand grid place-items-center shadow-brand">
                <s.icon className="size-6 text-brand-foreground" strokeWidth={2.2} />
              </div>
              <h3 className="mt-5 text-xl font-bold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              <a href="#contact" className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:text-primary transition-colors">
                Learn more <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function SectionHead({ eyebrow, title, subtitle, light }: { eyebrow: string; title: string; subtitle?: string; light?: boolean }) {
  return (
    <div className="text-center max-w-2xl mx-auto">
      <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${light ? "bg-primary/20 text-primary" : "bg-primary/15 text-foreground"}`}>{eyebrow}</span>
      <h2 className={`mt-4 font-display font-extrabold text-3xl md:text-5xl tracking-tight ${light ? "text-background" : ""}`}>{title}</h2>
      {subtitle && <p className={`mt-4 text-base md:text-lg ${light ? "text-background/70" : "text-muted-foreground"}`}>{subtitle}</p>}
    </div>
  );
}
