import { motion } from "framer-motion";
import { ClipboardList, Car, CheckCircle2 } from "lucide-react";
import { SectionHead } from "./Services";

const steps = [
  { icon: ClipboardList, title: "Enter Trip Details", desc: "Tell us your pickup, drop, date and time." },
  { icon: Car, title: "Choose Your Cab", desc: "Pick from sedan, SUV or Innova at upfront fares." },
  { icon: CheckCircle2, title: "Confirm & Ride", desc: "Get instant confirmation and meet your driver." },
];

export function HowItWorks() {
  return (
    <section className="py-20 md:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="How It Works" title="Book your taxi in 3 simple steps" />
        <div className="mt-12 relative grid md:grid-cols-3 gap-8">
          <div className="hidden md:block absolute top-10 left-[16%] right-[16%] h-0.5 bg-gradient-to-r from-primary/30 via-primary to-primary/30" />
          {steps.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative text-center"
            >
              <div className="relative inline-flex">
                <div className="size-20 rounded-3xl bg-card border border-border shadow-elevated grid place-items-center relative z-10">
                  <s.icon className="size-8 text-foreground" />
                </div>
                <div className="absolute -top-2 -right-2 size-8 rounded-full bg-gradient-brand text-brand-foreground font-bold text-sm grid place-items-center shadow-brand z-20">
                  {i + 1}
                </div>
              </div>
              <h3 className="mt-5 font-display font-bold text-xl">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-xs mx-auto">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
