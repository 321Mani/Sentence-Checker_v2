import { motion } from "framer-motion";
import { Phone, MessageCircle, Car, MapPin, Mail, Instagram, Facebook, Youtube } from "lucide-react";

export function CtaSection() {
  return (
    <section id="contact" className="py-20 md:py-28 bg-ink relative overflow-hidden">
      <div className="absolute -top-20 -right-20 size-96 bg-primary/30 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -left-20 size-96 bg-primary/20 rounded-full blur-3xl" />
      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-primary/20 text-primary">
            Ready to ride
          </span>
          <h2 className="mt-5 font-display font-extrabold text-4xl md:text-6xl text-background tracking-tight">
            Ready To Ride With <span className="text-primary">We Taxi?</span>
          </h2>
          <p className="mt-5 text-background/70 text-lg max-w-xl mx-auto">
            Book your ride in under 60 seconds. Talk to our team or message us on WhatsApp — we'll handle the rest.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <a href="#home" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full bg-gradient-brand text-brand-foreground font-semibold shadow-brand hover:scale-[1.03] active:scale-95 transition">
              <Car className="size-4" /> Book Now
            </a>
            <a href="https://wa.me/919999999999" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full bg-background/10 text-background font-semibold border border-background/20 hover:bg-background/20 transition">
              <MessageCircle className="size-4" /> WhatsApp Us
            </a>
            <a href="tel:+919999999999" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full bg-background text-foreground font-semibold hover:scale-[1.03] transition">
              <Phone className="size-4" /> Call Now
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-ink text-background/70 pt-16 pb-8 border-t border-background/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-4 gap-10">
          <div className="lg:col-span-1">
            <a href="#home" className="flex items-center gap-2">
              <div className="size-10 rounded-xl bg-gradient-brand grid place-items-center">
                <Car className="size-5 text-brand-foreground" strokeWidth={2.5} />
              </div>
              <span className="font-display font-extrabold text-xl text-background">
                We<span className="text-primary">Taxi</span>
              </span>
            </a>
            <p className="mt-4 text-sm leading-relaxed">
              Tamil Nadu's most trusted intercity taxi service. Safe, affordable and on-time — every single ride.
            </p>
            <div className="mt-5 flex gap-2">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="size-9 rounded-full bg-background/10 grid place-items-center hover:bg-primary hover:text-brand-foreground transition-colors">
                  <Icon className="size-4" />
                </a>
              ))}
            </div>
          </div>

          <FooterCol title="Quick Links" links={["Home", "Services", "Fleet", "About", "Contact"]} />
          <FooterCol title="Popular Routes" links={["Chennai → Bangalore", "Chennai → Pondicherry", "Chennai → Madurai", "Chennai → Coimbatore", "Madurai → Rameswaram"]} />

          <div>
            <h4 className="font-display font-bold text-background">Contact</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex gap-2"><Phone className="size-4 text-primary shrink-0 mt-0.5" /> +91 99999 99999</li>
              <li className="flex gap-2"><MessageCircle className="size-4 text-primary shrink-0 mt-0.5" /> WhatsApp Support</li>
              <li className="flex gap-2"><Mail className="size-4 text-primary shrink-0 mt-0.5" /> hello@wetaxi.in</li>
              <li className="flex gap-2"><MapPin className="size-4 text-primary shrink-0 mt-0.5" /> Chennai, Tamil Nadu</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-background/10 flex flex-col sm:flex-row justify-between gap-3 text-xs">
          <p>© {new Date().getFullYear()} We Taxi. All rights reserved.</p>
          <p>Made with ❤ in Tamil Nadu</p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <h4 className="font-display font-bold text-background">{title}</h4>
      <ul className="mt-4 space-y-2.5 text-sm">
        {links.map((l) => (
          <li key={l}><a href="#" className="hover:text-primary transition-colors">{l}</a></li>
        ))}
      </ul>
    </div>
  );
}

export function FloatingWhatsapp() {
  return (
    <a
      href="https://wa.me/919999999999"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-40 size-14 rounded-full grid place-items-center text-white shadow-elevated hover:scale-110 transition-transform"
      style={{ backgroundColor: "oklch(0.65 0.17 150)" }}
    >
      <MessageCircle className="size-6" />
      <span className="absolute inset-0 rounded-full animate-ping" style={{ backgroundColor: "oklch(0.65 0.17 150 / 0.4)" }} />
    </a>
  );
}

export function StickyMobileCta() {
  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-background/95 backdrop-blur-lg border-t border-border p-3 flex gap-2 shadow-elevated">
      <a href="tel:+919999999999" className="flex-1 inline-flex items-center justify-center gap-2 py-3 rounded-full border border-border font-semibold text-sm">
        <Phone className="size-4" /> Call
      </a>
      <a href="#home" className="flex-1 inline-flex items-center justify-center gap-2 py-3 rounded-full bg-gradient-brand text-brand-foreground font-semibold text-sm shadow-brand">
        <Car className="size-4" /> Book Now
      </a>
    </div>
  );
}
