import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import { SectionHead } from "./Services";

const cities = ["Chennai", "Coimbatore", "Madurai", "Salem", "Trichy", "Tirunelveli", "Pondicherry", "Bangalore", "Tirupati"];

export function Coverage() {
  return (
    <section className="py-20 md:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="Coverage" title="We serve across South India" subtitle="Pickup and drop in 100+ cities across Tamil Nadu and neighbouring states." />
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {cities.map((city, i) => (
            <motion.div
              key={city}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
              whileHover={{ y: -4 }}
              className="bg-card rounded-2xl p-5 border border-border shadow-soft hover:border-primary hover:shadow-brand transition-all cursor-pointer flex items-center gap-3"
            >
              <div className="size-9 rounded-xl bg-primary/15 grid place-items-center">
                <MapPin className="size-4 text-foreground" />
              </div>
              <span className="font-semibold text-sm">{city}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
