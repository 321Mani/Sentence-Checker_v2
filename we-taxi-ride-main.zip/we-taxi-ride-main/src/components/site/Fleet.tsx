import { motion } from "framer-motion";
import { Users, Snowflake, Briefcase, ArrowRight } from "lucide-react";
import { SectionHead } from "./Services";
import hatchback from "@/assets/car-hatchback.jpg";
import sedan from "@/assets/car-sedan.jpg";
import suv from "@/assets/car-suv.jpg";
import innova from "@/assets/car-innova.jpg";

const fleet = [
  { name: "Hatchback", img: hatchback, seats: 4, bags: 2, price: 12, eg: "Swift / WagonR" },
  { name: "Sedan", img: sedan, seats: 4, bags: 3, price: 14, eg: "Etios / Dzire" },
  { name: "SUV", img: suv, seats: 6, bags: 4, price: 18, eg: "Ertiga / XL6" },
  { name: "Innova Crysta", img: innova, seats: 7, bags: 5, price: 20, eg: "Premium MPV" },
];

export function Fleet() {
  return (
    <section id="fleet" className="py-20 md:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="Our Fleet" title="Pick the perfect ride for your journey" subtitle="Well-maintained, sanitized cars driven by professional chauffeurs." />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {fleet.map((f, i) => (
            <motion.div
              key={f.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.08 }}
              whileHover={{ y: -8 }}
              className="group bg-card rounded-3xl overflow-hidden border border-border shadow-soft hover:shadow-elevated transition-all"
            >
              <div className="relative aspect-[4/3] bg-muted overflow-hidden">
                <img src={f.img} alt={f.name} loading="lazy" width={800} height={600} className="size-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-primary text-brand-foreground text-[11px] font-bold">
                  ₹{f.price}/km
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-display font-bold text-lg">{f.name}</h3>
                <p className="text-xs text-muted-foreground">{f.eg}</p>
                <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Users className="size-3.5" /> {f.seats} seats</span>
                  <span className="flex items-center gap-1"><Snowflake className="size-3.5" /> AC</span>
                  <span className="flex items-center gap-1"><Briefcase className="size-3.5" /> {f.bags} bags</span>
                </div>
                <button className="mt-4 w-full inline-flex items-center justify-center gap-1.5 py-2.5 rounded-full bg-foreground/5 text-foreground text-sm font-semibold hover:bg-primary hover:text-brand-foreground transition-colors">
                  Book Now <ArrowRight className="size-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
