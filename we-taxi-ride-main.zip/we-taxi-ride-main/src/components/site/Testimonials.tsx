import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { SectionHead } from "./Services";

const reviews = [
  { name: "Priya Sundaram", route: "Chennai → Madurai", rating: 5, text: "Driver was very professional and the car was spotless. Reached on time without any hassle. Highly recommend We Taxi!" },
  { name: "Karthik R.", route: "Coimbatore → Bangalore", rating: 5, text: "Transparent pricing with no last-minute surprises. Smooth booking experience and comfortable Innova for our family trip." },
  { name: "Aishwarya M.", route: "Chennai Airport Pickup", rating: 5, text: "Perfect for airport transfers. The driver was waiting before my flight landed. Will book again for sure." },
  { name: "Vignesh K.", route: "Chennai → Pondicherry", rating: 5, text: "Used them twice for weekend trips. Both times the experience was great. Safe driving and clean cars." },
];

export function Testimonials() {
  return (
    <section className="py-20 md:py-28 bg-muted/40 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SectionHead eyebrow="Testimonials" title="Loved by 50,000+ travellers" />
      </div>
      <div className="mt-12 overflow-x-auto scrollbar-hide snap-x snap-mandatory">
        <div className="flex gap-5 px-4 sm:px-6 pb-4 max-w-7xl mx-auto">
          {reviews.map((r, i) => (
            <motion.article
              key={r.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="snap-start shrink-0 w-[320px] md:w-[380px] bg-card rounded-3xl p-7 border border-border shadow-soft"
            >
              <Quote className="size-7 text-primary" />
              <p className="mt-4 text-sm text-foreground/80 leading-relaxed">"{r.text}"</p>
              <div className="mt-6 flex items-center gap-3 pt-4 border-t border-border">
                <div className="size-11 rounded-full bg-gradient-brand grid place-items-center font-display font-bold text-brand-foreground">
                  {r.name[0]}
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.route}</div>
                </div>
                <div className="flex">
                  {Array.from({ length: r.rating }).map((_, i) => (
                    <Star key={i} className="size-3.5 fill-primary text-primary" />
                  ))}
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
