import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { Counters } from "@/components/site/Counters";
import { Services } from "@/components/site/Services";
import { PopularRoutes } from "@/components/site/Routes";
import { Fleet } from "@/components/site/Fleet";
import { WhyUs } from "@/components/site/WhyUs";
import { HowItWorks } from "@/components/site/HowItWorks";
import { Testimonials } from "@/components/site/Testimonials";
import { Coverage } from "@/components/site/Coverage";
import { Faq } from "@/components/site/Faq";
import { CtaSection, Footer, FloatingWhatsapp, StickyMobileCta } from "@/components/site/CtaFooter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "We Taxi — Book One-Way & Outstation Taxi in Tamil Nadu" },
      { name: "description", content: "Premium one-way and outstation taxi service across Tamil Nadu. Airport transfers, intercity rides and tour packages with verified drivers and transparent fares." },
      { property: "og:title", content: "We Taxi — Premium Intercity Taxi in Tamil Nadu" },
      { property: "og:description", content: "Safe, reliable and affordable taxi service. Book one-way, round trip, airport and outstation cabs across South India." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        name: "We Taxi",
        description: "Premium one-way and outstation taxi service in Tamil Nadu.",
        telephone: "+91-99999-99999",
        areaServed: "Tamil Nadu, India",
        aggregateRating: { "@type": "AggregateRating", ratingValue: "4.9", reviewCount: "50000" },
      }),
    }],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      <main>
        <Hero />
        <Counters />
        <Services />
        <PopularRoutes />
        <Fleet />
        <WhyUs />
        <HowItWorks />
        <Testimonials />
        <Coverage />
        <Faq />
        <CtaSection />
      </main>
      <Footer />
      <FloatingWhatsapp />
      <StickyMobileCta />
    </div>
  );
}
